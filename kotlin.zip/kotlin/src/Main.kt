//////////////////////////////// TASK ALE 2 ///////////////////////////////////////
//fun main() {
//    val word = "ale ela"
//
//    var aleWord = ""
//    var didiSigrdze = word.length
//
//    for (i in (didiSigrdze - 1) downTo 0) {
//        aleWord = aleWord + word[i]
//    }
//
//    if (word.equals(aleWord, ignoreCase = true)) {
//        println("aleuria")
//    } else {
//        println("arari aleuri")
//    }
//}



fun main() {

    val arrayList = [1, 2, 3, 4, 5, 6]
    val even = 0

    

}
