class FactoryProvider {
    companion object {
        fun getFactory(factoryType: String): AbstractFactory<*>? {
            return when (factoryType) {
                "Car" -> CarFactory()
                "Aircraft" -> AircraftFactory()
                else -> null
            }
        }
    }
}