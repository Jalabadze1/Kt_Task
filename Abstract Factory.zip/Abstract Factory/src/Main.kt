import kotlin.math.pow
import kotlin.math.sqrt

class Point(x: Number, y: Number) {
    var x: Double;
    var y: Double;

    init {
        this.x = x.toDouble()
        this.y = y.toDouble()
    }

    override fun toString(): String {
        return "x: $x y: $y"
    }
    override fun equals(other: Any?): Boolean {
        return when(other){
            is Point -> {
                this.x == other.x && this.y == other.y
            }
            else -> false
        }
    }

    fun distanceBetween(other: Point): Double {
        return sqrt((this.y - other.y).pow(2) + (this.x - other.x).pow(2))
    }
}